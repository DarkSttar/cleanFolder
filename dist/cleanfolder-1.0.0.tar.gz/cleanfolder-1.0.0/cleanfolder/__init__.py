from clean_folder import main
from clean_folder import parser_1
from clean_folder import normilized


